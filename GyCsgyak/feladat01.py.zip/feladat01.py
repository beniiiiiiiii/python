# feladat.py

# 1. feladat
# Készítsen függvényt nagyobb néven
# A függvény bemeneti paramétere két egész szám
# A függvény egész számot adjon vissza
# A függvény térjen vissza a két szám közül a nagyobbikkal

def nagyobb(szam1:int, szam2:int)->int:

# Tesztelje a függvényt a következő paraméterekkel: (5,3), (3,5), (3,3)
print("1. feladat")
eredmeny1=nagyobb(5,3)
print(eredmeny1)

eredmeny2=nagyobb(3,5)
print(eredmeny2)

eredmeny3=nagyobb(5,5)
print(eredmeny3)


# 2. feladat
# Készítsen függvényt osszeg néven
# A függvény bemeneti paramétere két egész szám
# A függvény egész számot adjon vissza
# A függvény térjen vissza a két szám összegével

# Tesztelje a függvényt a következő paraméterekkel: (5,3), (-3,-5), (3,-5)



# 3. feladat
# Készítsen függvényt a téglalap területének meghatározására
# A függvény neve legyen teglalap_terulet
# A függvény bemeneti paramétere két valós szám, a téglalap oldalai
# A függvény valós számot adjon vissza
# Ha a téglalapnak nem értelmezhető a területe térjen vissza a None értékkel

# Tesztelje a függvényt a következő paraméterekkel: (5.3, 2.8), (0, 10), (-10,0)


# 4. feladat
# Készítsen függvényt a kör területének meghatározására
# A függvény neve legyen kor_terulet
# A függvény bemeneti paramétere egy valós szám, a kör sugara
# A függvény valós számot adjon vissza
# Ha a kör területe nem értelmezhető a területe térjen vissza a None értékkel

# Tesztelje a függvényt a következő paraméterekkel: 5.38, 0, -10